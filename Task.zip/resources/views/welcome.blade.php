<!DOCTYPE html>
<html lang="en">
<head>
    <title>Bootstrap Example</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
    <h2>Gismat Mammadov</h2>
    <div class="panel-group">
        <div class="panel panel-info">
            <div class="panel-heading">TASK </div>
            <div class="panel-body">
                <button class="btn btn-primary"><a style="color: white" href="{!! url('/task1') !!}">Task1</a></button>
                <button class="btn btn-primary"><a style="color: white" href="{!! url('/task2') !!}">Task2</a></button>
            </div>
        </div>
        </div>
    </div>

</body>
</html>
