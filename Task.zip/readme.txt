Kodun lokalda işlənməsi üçün githubdan yuklenmish zipp faylı xampp serverin(bu digər serverde ola biler) icinde olan htdocs papqasının içində zippdən cixarmağınız lazımdır,
daha sonra cmd-den hemin papqanın içinə gedib php artisan serve əmrini yerinə yetirməyiniz tələb olunur cünki program Laravelle yazılmışdır

Eyni zamanda programa göndərilmiş linkdəndə baxa bilərsiniz.

PS: Nəzərinizə çatdırmaq istəyirəmki https://www.cbar.az/ saytı 29.09.2020 tarixindən əlçatan deyil bu sebebden dolayı birinci tapşırığı
yoxlamaq istediyiniz zaman eger sehife cox yüklənər və error qarşınıza çıxar bu XML faylının əlçatan olmadığınnan dolayı baş verir ki buda programın səhvi deyil.

PS: İkinci tapşırıqda şəhərlərin adlarını statik olaraq teyin etmişəm yəni bazaya yazıb daha sonra çağırmadan və əsas bizə lazım olan şəhərin adıdır ki,
şəhərin adını göndərməklə apidən məlumatları çəkə bilək, bunuda etdiyimi düşünürəm, sadəcə xəbərdar olmağınız üçün qeyd edirem bunu ve
 menimde xeberdar olduğumu bildirmek isteyirem



